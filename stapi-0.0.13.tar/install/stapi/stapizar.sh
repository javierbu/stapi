#!/bin/bash
tar -xf archivos.tar
mv /etc/ssh_banner /etc/ssh_banner.bk_generada_por_stapi &>/dev/null
mv ssh_banner /etc/
mv /etc/ssh/sshd_config /etc/ssh/sshd_config.bk_generada_por_stapi
mv sshd_config /etc/ssh/sshd_config
mv /root/.bashrc /root/.bashrc.bk_generada_por_stapi
mv bashrc /root/.bashrc
mv /etc/motd /etc/motp.bk_generado_por_stapi
touch /etc/motd
mv /etc/hostname /etc/hostname.bk_generado_por_stapi
echo "STAPi" > /etc/hostname
echo " Completado. Los cambios se haran efectivos cuando inicies una nueva sesion."
exit

