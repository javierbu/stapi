#!/bin/bash
#by chewwe
######################
##################################
CYAN=`echo -e "\033[01;36m"`
VERDE=`echo -e "\e[32m"`
NORMAL=`echo -e "\e[0m"`
AZUL=`echo -e "\e[34m"`
ROJO=`echo -e "\e[31m"`
BLANCO=`echo -e "\033[1;37m"`
ULTRAVERDE=`echo -e "\e[1;32m"`
AMARILLO=`echo -e "\e[1;33m"`
VIOLETA=`echo -e "\e[1;35m"`
#################################
apt-get update
if [ $? = "0" ]; then
	echo "${VERDE}[++]${NORMAL} Upgrade realizado con exito"
else
	echo "${ROJO}[XX]${NORMAL} Algo salio mal. Por favor comprueba tu conexion a internet y vuelve a intentarlo."
	exit
fi
apt-get install  sshpass reaver aircrack-ng mana-toolkit kismet gpsd gpsd-clients util-linux procps hostapd iproute2 iw haveged bash-completion
if [ $? = "0" ]; then
        echo "${VERDE}[++]${NORMAL} Dependencias instaladas con exito"
else
        echo "${ROJO}[XX]${NORMAL} Algo salio mal. Por favor comprueba posibles causas y prueba de nuevo."
	exit
fi
echo "${AMARILLO}[::]${NORMAL} Distribuyendo archivos"
tar -xf scripts.tar -C /root/
if [ $? = "0" ]; then
        echo "${VERDE}[++]${NORMAL} Ok!"
else
        echo "${ROJO}[XX]${NORMAL} Algo salio mal. Por favor comprueba posibles causas y prueba de nuevo."
        exit
fi
#tar -xf bin.tar -C /usr/local/bin
#if [ $? = "0" ]; then
#        echo "${VERDE}[++]${NORMAL} Ok!"
#else
#        echo "${ROJO}[XX]${NORMAL} Algo salio mal. Por favor comprueba posibles causas y prueba de nuevo."
#        exit
#fi
#tar -xf pitunel.tar -C /etc/
#if [ $? = "0" ]; then
#        echo "${VERDE}[++]${NORMAL} Ok!"
#else
#        echo "${ROJO}[XX]${NORMAL} Algo salio mal. Por favor comprueba posibles causas y prueba de nuevo."
#        exit
#fi
#tar -xf inicio.tar -C /
#if [ $? = "0" ]; then
#        echo "${VERDE}[++]${NORMAL} Ok!"
#else
#        echo "${ROJO}[XX]${NORMAL} Algo salio mal. Por favor comprueba posibles causas y prueba de nuevo."
#        exit
#fi
tar -xf config.tar
if [ $? = "0" ]; then
        echo "${VERDE}[++]${NORMAL} Ok!"
else
        echo "${ROJO}[XX]${NORMAL} Algo salio mal. Por favor comprueba posibles causas y prueba de nuevo."
        exit
fi
echo "${VERDE}[++]${NORMAL} Archivos en su sitio!!"
echo "${AMARILLO}[::]${NORMAL} Creando carpetas /var/log/stapi/ y /root/github/"
mkdir /var/log/stapi  &>/dev/null
mkdir /root/github &>/dev/null
echo "${VERDE}[++]${NORMAL} Archivos en su sitio!!"
cd /root/github
echo "${AMARILLO}[::]${NORMAL} Descargando e instalando create_ap.."
git clone https://github.com/oblique/create_ap &>/dev/null
cd create_ap
make install
if [ $? = "0" ]; then
        echo "${VERDE}[++]${NORMAL} Create_ap instalado con exito!"
else
        echo "${ROJO}[XX]${NORMAL} Algo salio mal. Por favor comprueba posibles causas y prueba de nuevo."
        exit
fi
echo "${AMARILLO}[::]${NORMAL} Creando archivo /erc/rc.local y asignando permisos.."
echo "#!/bin/sh -e
bash /root/scripts/sistema/inicio.sh &>/tmp/inicio.log
exit 0" > /etc/rc.local
chmod +x /etc/rc.local
echo "${VERDE}[++]${NORMAL} /etc/rc.local creado con sus debidos permisos."
echo "${AMARILLO}[::]${NORMAL} Creando enlaces a welcomel tunel, tunelvnc, create_ap_mana y constructor.."
ln /root/scripts/constructor/constructor /usr/local/bin/constructor
ln /root/scripts/sistema/welcome /usr/local/bin/welcome
ln /root/scripts/sistema/tunel /usr/local/bin/tunel
ln /root/scripts/sistema/tunelvnc /usr/local/bin/tunelvnc
ln /root/scripts/sistema/create_ap_mana /usr/local/bin/create_ap_mana
echo "${VERDE}[++]${NORMAL} Enlaces creados"
echo "${AMARILLO}[::]${NORMAL} Creando archivos de configuracion necesarios para wardriving.."
mkdir /var/log/kismet &>/dev/null
chmod 777 /var/log/kismet/ &>/dev/null
mv /etc/kismet/kismet.conf /etc/kismet/kismet.conf.bk_generada_por_stapi &>/dev/null
cd /root/install
mv kismet.conf /etc/kismet/
mv /etc/default/gpsd /etc/default/gpsd.bk_generado_por_stapi &>/dev/null
mv gpsd /etc/default/gpsd
echo "${VERDE}[++]${NORMAL} Todo en su sitio."
echo "${VERDE}[++]${NORMAL} Esto es todo. Bienvenido a STAPi. Usa constructor para cargar ataques"
echo "${VERDE}[++]${NORMAL} Si quieres \"stapizar\" tu sistema, ejecuta stapizar.sh en la carpeta stapi."
exit
